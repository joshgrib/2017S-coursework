Josh Gribbon
Homework 04
SSW555 Agile Methods for Software Development
2017-02-19

FILES
* main.py - code
* tests.py - the test script

Run "python tests.py" to run tests
